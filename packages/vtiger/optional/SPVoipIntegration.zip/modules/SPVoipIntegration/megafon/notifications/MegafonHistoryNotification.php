<?php
namespace SPVoipIntegration\megafon\notifications;

use SPVoipIntegration\gravitel\notifications\GravitelHistoryNotification;

class MegafonHistoryNotification extends GravitelHistoryNotification {
    use GravitelAdapterTrait;    
}
