<?php

namespace SPVoipIntegration\yandex\notifications;

class CallbackCallStopRinging extends IncomingCallStopRinging{
    
}
