<?php

namespace SPVoipIntegration\zebra\notifications;
class ZebraEventType {
    const CREATE = 'CHANNEL_CREATE';
    CONST ANSWER = 'CHANNEL_ANSWER';
    CONST DESTROY = 'CHANNEL_DESTROY';
}
