<?php

namespace SPVoipIntegration\yandex\notifications;

class IncomingCallConnected extends OutgoingCallConnected{

}
