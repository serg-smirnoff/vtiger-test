<?php
namespace SPVoipIntegration\sipuni\notifications;

class SipuniNotifySecHangUp extends SipuniNotifyHangUp {
}