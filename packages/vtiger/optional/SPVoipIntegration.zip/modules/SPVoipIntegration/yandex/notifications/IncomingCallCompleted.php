<?php

namespace SPVoipIntegration\yandex\notifications;

class IncomingCallCompleted extends OutgoingCallCompleted{    
}
