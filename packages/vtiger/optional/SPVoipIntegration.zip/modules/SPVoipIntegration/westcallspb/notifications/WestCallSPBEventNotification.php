<?php
namespace SPVoipIntegration\westcallspb\notifications;

use SPVoipIntegration\gravitel\notifications\GravitelEventNotification;

class WestCallSPBEventNotification extends GravitelEventNotification {        
    use GravitelAdapterTrait;
}