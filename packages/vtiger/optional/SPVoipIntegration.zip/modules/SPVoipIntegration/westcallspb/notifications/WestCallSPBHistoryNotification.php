<?php
namespace SPVoipIntegration\westcallspb\notifications;

use SPVoipIntegration\gravitel\notifications\GravitelHistoryNotification;

class WestCallSPBHistoryNotification extends GravitelHistoryNotification {
    use GravitelAdapterTrait;    
}

