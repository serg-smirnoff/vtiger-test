<?php

namespace SPVoipIntegration\domru\notifications;

use SPVoipIntegration\gravitel\notifications\GravitelEventNotification;

class DomruEventNotification extends GravitelEventNotification {        
    use GravitelAdapterTrait;
}
