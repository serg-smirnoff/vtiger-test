<?php

namespace SPVoipIntegration\mcntelecom\notifications;

class MCNOutboundMissed extends MCNInboundMissed{
    
}
