<?php

namespace SPVoipIntegration\yandex\notifications;

class CallbackCallRinging extends OutgoingCall{
    
}
